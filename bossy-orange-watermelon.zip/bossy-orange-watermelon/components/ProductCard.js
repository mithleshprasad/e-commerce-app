import React from 'react';
import { View, Text, Image, StyleSheet, TouchableOpacity, Animated } from 'react-native';

const ProductCard = ({ product, onPress }) => {
  const scale = new Animated.Value(1); // Initialize scale value for animation

  const handlePressIn = () => {
    // Scale the card down when pressed
    Animated.spring(scale, {
      toValue: 0.95,
      friction: 3,
      tension: 100,
      useNativeDriver: true,
    }).start();
  };

  const handlePressOut = () => {
    // Return the card back to its original size
    Animated.spring(scale, {
      toValue: 1,
      friction: 3,
      tension: 100,
      useNativeDriver: true,
    }).start();
  };

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={onPress}
      onPressIn={handlePressIn}
      onPressOut={handlePressOut}
    >
      <Animated.View style={[styles.cardContent, { transform: [{ scale }] }]}>
        <Image source={{ uri: product.image }} style={styles.image} />
        <Text style={styles.title}>{product.title}</Text>
        <Text style={styles.price}>${product.price.toFixed(2)}</Text>
      </Animated.View>
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  card: {
    backgroundColor: '#fff',
    // borderRadius: 12,
    padding: 10,
    marginBottom: 15,
    // shadowColor: '#000',
    shadowOpacity: 0.1,
    // shadowRadius: 8,
    elevation: 6,
    overflow: 'hidden', // Make sure the image and text don't overflow the card's border radius
  },
  cardContent: {
    backgroundColor: '#fff',
    borderRadius: 12,
    padding: 10,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  image: {
    height: 120,
    width: '100%',
    resizeMode: 'contain',
    borderRadius: 8,
  },
  title: {
    fontSize: 16,
    fontWeight: 'bold',
    marginTop: 10,
    color: '#333',
  },
  price: {
    fontSize: 16,
    color: '#007BFF',
    marginTop: 5,
    fontWeight: '600',
  },
});

export default ProductCard;
