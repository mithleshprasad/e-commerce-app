import React,{useContext} from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Ionicons } from '@expo/vector-icons'; // Icon library
import { CartContext } from '../context/CartContext'; // Import the CartContext

const CustomDrawerContent = () => {
  const navigation = useNavigation();
  const { cartItems } = useContext(CartContext);
console.log(cartItems)
  // Calculate the total number of items in the cart
  // const totalItems = cartItems.length;
  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>My App</Text>
      </View>

      {/* Menu Items */}
      <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Profile')}>
        <Ionicons name="person-outline" size={24} color="black" style={styles.icon} />
        <Text style={styles.itemText}>Profile</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Home')}>
        <Ionicons name="home-outline" size={24} color="black" style={styles.icon} />
        <Text style={styles.itemText}>Home</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Checkout')}>
        <Ionicons name="cart-outline" size={24} color="black" style={styles.icon} />
        <Text style={styles.itemText}>Checkout</Text>
      </TouchableOpacity>

      <TouchableOpacity style={styles.menuItem} onPress={() => navigation.navigate('Cart')}>
        <Ionicons name="basket-outline" size={24} color="black" style={styles.icon} />
        <Text style={styles.itemText}>Cart</Text>
      </TouchableOpacity>

  
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f4f4f4', // Light background color
  },
  header: {
    padding: 20,
    backgroundColor: '#000', // Blue header background
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 26,
    fontWeight: 'bold',
    color: '#fff', // White text color for header
  },
  menuItem: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingVertical: 15,
    paddingHorizontal: 20,
    borderBottomWidth: 1,
    borderBottomColor: '#ddd',
  },
  icon: {
    marginRight: 15,
  },
  itemText: {
    fontSize: 18,
    color: '#333', // Dark text color for better readability
  },
});

export default CustomDrawerContent;
