import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Image } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // For icons
import { useNavigation } from '@react-navigation/native';
import AsyncStorage from '@react-native-async-storage/async-storage';

const ProfileScreen = () => {
  const navigation = useNavigation();
  
  // State to hold user data
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('johndoe@example.com'); // Placeholder email
  const [profilePic, setProfilePic] = useState('https://www.w3schools.com/w3images/avatar2.png'); // Placeholder profile pic

  // Load the user's name from AsyncStorage when the component is mounted
  useEffect(() => {
    const getUserData = async () => {
      try {
        const savedName = await AsyncStorage.getItem('userName');
        if (savedName !== null) {
          setUserName(savedName);
        } else {
          setUserName('John Doe'); // Default name if no data in AsyncStorage
        }
      } catch (error) {
        console.error('Error loading user name:', error);
      }
    };
    getUserData();
  }, []);

  // Save the user's name to AsyncStorage
  const handleSaveName = async (name) => {
    try {
      await AsyncStorage.setItem('userName', name);
      setUserName(name);
    } catch (error) {
      console.error('Error saving user name:', error);
    }
  };

  const handleLogout = () => {
    // Handle the logout logic here (e.g., clear tokens, reset navigation)
    console.log('Logged out');
    navigation.navigate('Home');
  };

  return (
    <View style={styles.container}>
      {/* Profile Picture */}
      <Image source={{ uri: profilePic }} style={styles.profilePic} />

      {/* User Info */}
      <Text style={styles.name}>{userName}</Text>
      <Text style={styles.email}>{userEmail}</Text>

      {/* Edit Profile Button */}
      <TouchableOpacity
        style={styles.button}
        onPress={() => handleSaveName('Jane Doe')} // Just an example, replace with actual edit logic
      >
        <Ionicons name="pencil-outline" size={24} color="white" />
        <Text style={styles.buttonText}>Edit Profile</Text>
      </TouchableOpacity>

      {/* Logout Button */}
      <TouchableOpacity style={[styles.button, styles.logoutButton]} onPress={handleLogout}>
        <Ionicons name="log-out-outline" size={24} color="white" />
        <Text style={styles.buttonText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    backgroundColor: '#f4f4f4',
  },
  profilePic: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 3,
    borderColor: '#2196F3',
    marginBottom: 20,
  },
  name: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  email: {
    fontSize: 18,
    color: '#777',
    marginBottom: 20,
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#2196F3',
    paddingVertical: 12,
    paddingHorizontal: 25,
    borderRadius: 8,
    marginVertical: 10,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    marginLeft: 10,
  },
  logoutButton: {
    backgroundColor: '#f44336',
  },
});

export default ProfileScreen;
