import React, { useEffect, useState, useContext } from 'react';
import {
  View,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Text,
  TextInput,
  Image,
  ActivityIndicator,
} from 'react-native';
import axios from 'axios';
import ProductCard from '../components/ProductCard';
import { useNavigation } from '@react-navigation/native';
import { CartContext } from '../context/CartContext';

const HomeScreen = ({ navigation }) => {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const { cart, addToCart } = useContext(CartContext); // Using cart context

  useEffect(() => {
    axios
      .get('https://fakestoreapi.com/products')
      .then((response) => {
        setProducts(response.data);
        setFilteredProducts(response.data);
      })
      .catch((error) => {
        console.error(error);
      });
  }, []);

  const handleSearch = (text) => {
    setSearchTerm(text);
    const filtered = products.filter((product) =>
      product.title.toLowerCase().includes(text.toLowerCase())
    );
    setFilteredProducts(filtered);
  };

  const Header = () => (
    <View style={styles.headerContainer}>
      <TextInput
        style={styles.searchInput}
        placeholder="Search Products"
        value={searchTerm}
        onChangeText={handleSearch}
      />
      <TouchableOpacity onPress={() => navigation.navigate('Cart')}>
        <View style={styles.cartIcon}>
          <Image
            source={{
              uri: 'https://cdn.pixabay.com/photo/2014/04/02/10/53/shopping-cart-304843_640.png',
            }}
            style={styles.icon}
          />
          {cart.length > 0 && (
            <View style={styles.cartBadge}>
              <Text style={styles.cartCount}>{cart.length}</Text>
            </View>
          )}
        </View>
      </TouchableOpacity>
    </View>
  );

  if (!products.length) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <Header />
      <FlatList
        data={filteredProducts}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <ProductCard
            product={item}
            onPress={() => navigation.navigate('ProductDetails', { product: item })}
            addToCart={() => addToCart(item)} // Use addToCart from context
          />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#fff' },
  headerContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    // backgroundColor: '#f8f8f8',
    elevation: 5,
  },
  searchInput: {
    flex: 1,
    backgroundColor: '#fff',
    padding: 10,
    borderRadius: 5,
    marginHorizontal: 10,
    elevation: 3,
  },
  icon: { width: 30, height: 30 },
  cartIcon: { position: 'relative' },
  cartBadge: {
    position: 'absolute',
    top: -5,
    right: -5,
    backgroundColor: 'red',
    borderRadius: 10,
    padding: 3,
    
  },
  cartCount: { color: '#fff', fontSize: 12 },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});

export default HomeScreen;
