const AppDrawerNavigator = () => (
  <Drawer.Navigator drawerContent={() => <CustomDrawerContent />}>
    <Drawer.Screen name="Home" component={HomeScreen} />
    // <Drawer.Screen name="Categories" component={CategoriesScreen} />
    <Drawer.Screen name="Cart" component={CartScreen} />
    <Drawer.Screen name="Checkout" component={CheckoutScreen} />
    <Drawer.Screen name="Profile" component={ProfileScreen} />
  </Drawer.Navigator>
);
