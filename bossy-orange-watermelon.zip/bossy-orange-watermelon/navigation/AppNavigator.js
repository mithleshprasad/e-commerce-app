import React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createDrawerNavigator } from '@react-navigation/drawer';
import { createStackNavigator } from '@react-navigation/stack';
import HomeScreen from '../screens/HomeScreen';
import CartScreen from '../screens/CartScreen';
import ProductDetailsScreen from '../screens/ProductDetailsScreen';
import CustomDrawerContent from '../components/CustomDrawerContent';
import CheckoutScreen from '../screens/CheckoutScreen';
import ProfileScreen from '../screens/ProfileScreen';

const Stack = createStackNavigator();
const Drawer = createDrawerNavigator();

// Stack Navigator for main app flow
const AppStackNavigator = () => (
  <Stack.Navigator
    screenOptions={{
      headerShown: false, // Ensure header is shown for each screen
      headerTitleAlign: 'center', // Center the title
    }}
  >
    <Stack.Screen
      name="Home"
      component={HomeScreen}
      options={{
        headerTitle: 'Home', // Set the title for Home screen
      }}
    />
    <Stack.Screen
      name="ProductDetails"
      component={ProductDetailsScreen}
      options={{
        headerTitle: 'Product Details', // Set the title for Product Details screen
      }}
    />
    <Stack.Screen
      name="Checkout"
      component={CheckoutScreen}
      options={{
        headerTitle: 'Checkout', // Set the title for Checkout screen
      }}
    />
  </Stack.Navigator>
);

// Main App Navigator with Drawer Navigator
const AppNavigator = () => (
  <NavigationContainer>
    <Drawer.Navigator drawerContent={() => <CustomDrawerContent />}>
      <Drawer.Screen name="Home" component={AppStackNavigator} />
      <Drawer.Screen name="Cart" component={CartScreen} />
      <Drawer.Screen name="Checkout" component={CheckoutScreen} />
      <Drawer.Screen name="Profile" component={ProfileScreen} />
    </Drawer.Navigator>
  </NavigationContainer>
);

export default AppNavigator;
